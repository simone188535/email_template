sudo easy_install pip
sudo pip install pyexcel
sudo pip install pyexcel-xlsx
sudo pip install Pillow
sudo pip install natsort
sudo pip install mailchimp3
