Format
Image

Responsive
Image fits to width